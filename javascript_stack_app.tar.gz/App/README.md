# Deploy-AWS-ECS-Fargate-using-Terraform-and-Jenkins

⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️⬇️

https://medium.com/@mericac33/deploy-mern-stack-to-aws-fargate-using-terraform-and-jenkins-77b23a5803f9


<img width="627" alt="Photot" src="https://github.com/mericalp/Deploy-AWS-ECS-Fargate-using-Terraform-and-Jenkins/assets/83503845/7a0511d0-b627-41ab-9dcf-0f46d3fecff7">
